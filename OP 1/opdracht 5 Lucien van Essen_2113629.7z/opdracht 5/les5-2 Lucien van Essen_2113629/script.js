window.onload = function() {

    changeElm();

    function changeElm() {
        var elmValue = "dit moet ik veranderen";
        document.getElementById("myFirstDiv").innerHTML = elmValue;
    }

}