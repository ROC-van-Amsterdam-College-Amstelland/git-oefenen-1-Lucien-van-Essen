var myDinner = prompt("Wat wil je eten?");
var myAmount = prompt("Hoeveel wil je eten?");
var myPrice = 24.99;
alert(myAmount * myPrice);